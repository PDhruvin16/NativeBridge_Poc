# React Native My Native Bridge

A React Native library for bridging to native functionality.

## Installation

```bash
npm install react-native-my-native-bridge
```

## Usage

```typescript
import MyNativeBridge from 'react-native-my-native-bridge';

// Use the bridge
```

## Contributing

## License

ISC